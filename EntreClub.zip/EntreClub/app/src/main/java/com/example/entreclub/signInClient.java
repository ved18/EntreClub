package com.example.entreclub;

public class signInClient {

    private String password;

    public String getPassword() {
        return password;
    }
}
