package com.example.entreclub;

public class Logl {
    String amount;
    String service;
    String from;
    String to;


    public Logl(String service, String from, String to, String amount) {
        this.service = service;
        this.from = from;
        this.to = to;
        this.amount = amount;
    }

}